//
//  Weather_Data+CoreDataClass.swift
//  Aadarsh_Singh_FE_8939049
//
//  Created by user234932 on 12/11/23.
//
//

import Foundation
import CoreData

@objc(Weather_Data)
public class Weather_Data: NSManagedObject {

}
