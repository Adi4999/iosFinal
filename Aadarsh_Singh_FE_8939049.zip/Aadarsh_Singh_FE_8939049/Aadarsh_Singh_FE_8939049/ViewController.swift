

import UIKit
 
struct toDo: Codable {

    let text: String

    var complete: Bool

}
 
class ViewController: UIViewController {
 
    @IBOutlet weak var tableView: UITableView!

    var toDos = [toDo]()
 
    override func viewDidLoad() {

        super.viewDidLoad()
 
        tableView.delegate = self

        tableView.dataSource = self
 
        loadToDos()

    }
 
    @IBAction func AddButton(_ sender: Any) {

        let alert = UIAlertController(title: "Add Item", message: "Add Item", preferredStyle: .alert)
 
        alert.addTextField { (textField) in

            textField.placeholder = "Take out trash"

        }
 
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))

        let saveAction = UIAlertAction(title: "Save", style: .default) { (_) in

            if let toDotext = alert.textFields?.first?.text {

                self.toDos.append(toDo(text: toDotext, complete: false))

                self.tableView.reloadData()

                self.saveToDos()

            }

        }

        alert.addAction(saveAction)
 
        present(alert, animated: true)

    }
 
    func saveToDos() {

        let encodedData = try? JSONEncoder().encode(toDos)

        UserDefaults.standard.set(encodedData, forKey: "toDos")

    }
 
    func loadToDos() {

        if let data = UserDefaults.standard.data(forKey: "toDos"),

           let savedToDos = try? JSONDecoder().decode([toDo].self, from: data) {

            toDos = savedToDos

            tableView.reloadData()

        }

    }

}
 
extension ViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return toDos.count

    }
 
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let toDo = toDos[indexPath.row]
 
        let cell = UITableViewCell()

        cell.textLabel?.text = toDo.text
 
        if toDo.complete {

            cell.accessoryType = .checkmark

            cell.textLabel?.alpha = 0.5

        } else {

            cell.accessoryType = .none

            cell.textLabel?.alpha = 1.0

        }
 
        return cell

    }
 
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {

        if editingStyle == .delete {

            toDos.remove(at: indexPath.row)

            self.tableView.deleteRows(at: [indexPath], with: .fade)

            saveToDos()

        }

    }
 
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {

        return 70

    }
 
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        toDos[indexPath.row].complete.toggle()

        tableView.reloadData()

        saveToDos()

    }

}

 
