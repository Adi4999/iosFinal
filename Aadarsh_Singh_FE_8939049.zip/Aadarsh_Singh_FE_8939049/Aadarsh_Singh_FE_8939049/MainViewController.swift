

import UIKit
import CoreLocation
import MapKit

class MainViewController: UIViewController, CLLocationManagerDelegate  {


    @IBOutlet weak var mapView: MKMapView!
    var locationManager: CLLocationManager!
    
    @IBAction func discoverWorld(_ sender: UIButton) {
        showCityAlert()

    }
    
    @IBAction func weatherButton(_ sender: UIButton) {
      
    }
    
    func showCityAlert(){
        let alert = UIAlertController(title: "Where would you like to go?",message: "Enter your destination", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "News", style: .default, handler: {action in if let cityName = alert.textFields?.first?.text, !cityName.isEmpty {
            self.navigateToNewsPage(data: cityName)
        }
            else{
                self.showAlert(message: "Please enter the name of the city")
            }
            }))
        alert.addAction(UIAlertAction(title: "Directions", style: .default, handler: {action in
            if let cityName = alert.textFields?.first?.text, !cityName.isEmpty {
                self.navigateToMapPage(data: cityName)
            }
            else{
                self.showAlert(message: "Please enter the name of the city")
            }
        }))
        alert.addAction(UIAlertAction(title: "Weather",style: .default, handler: {action in if let cityName = alert.textFields?.first?.text, !cityName.isEmpty {
            self.navigateToWeatherPage(data: cityName)
        }
            else{
                self.showAlert(message: "Please enter the name of the city")
            }
            }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: {action in print("tapped cancel")}))
        alert.addTextField{field in field.placeholder = "Write a place"}
        
        present(alert, animated: true)
    }
    
    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    func navigateToMapPage(data: String) {
        print("tapped map")
            guard let map = storyboard?.instantiateViewController(withIdentifier: "MapsViewController") as? MapsViewController else {
                return
            }
        map.city = data // Pass data to NextViewController
        navigationController?.pushViewController(map, animated: true)
        }
    
    func navigateToWeatherPage(data: String) {
        print("tapped weather")
            guard let weather = storyboard?.instantiateViewController(withIdentifier: "WeatherViewController") as? WeatherViewController else {
                return
            }
        weather.city = data
        navigationController?.pushViewController(weather, animated: true)
        }
    
    func navigateToNewsPage(data: String) {
        print("tapped news")
        guard let news = storyboard?.instantiateViewController(withIdentifier: "NewsTableViewController") as? NewsTableViewController else {
            return
             }
        news.city = data
        navigationController?.pushViewController(news, animated: true)

           }

    override func viewDidLoad() {
        super.viewDidLoad()

        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
               
        mapView.showsUserLocation = true
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            guard let location = locations.first else { return }
            let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
            mapView.setRegion(region, animated: true)
        }
    

   

}
