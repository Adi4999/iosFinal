

import UIKit
import MapKit
import CoreLocation

class MapsViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var map: MKMapView!
    
    @IBOutlet weak var slider: UISlider!
    
    var userLocation: CLLocation?
    var destinationCoordinate: CLLocationCoordinate2D?
    let locationManager = CLLocationManager()
    
    var city: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        map.delegate = self
        // Request location authorization and access
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
      
        map.showsUserLocation = true
        locationManager.startUpdatingLocation()
        
        addPinForUserLocation()
        addPinForDestination()
        
        slider.minimumValue = 0
        slider.maximumValue = 10
        slider.addTarget(self, action: #selector(zoomMap(_:)), for: .valueChanged)
        
    }
    
    @objc func zoomMap(_ sender: UISlider) {
        let value = sender.value
        let region = MKCoordinateRegion(center: map.centerCoordinate, latitudinalMeters: Double(value) * 1000, longitudinalMeters: Double(value) * 1000)
        map.setRegion(region, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
         guard let location = locations.first else { return }
         userLocation = location
        let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
        map.setRegion(region, animated: true)
        addPinForUserLocation()
     }
     
     func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
         if status == .authorizedWhenInUse {
             locationManager.startUpdatingLocation()
         }
     }
    
    func addPinForUserLocation() {
           guard let location = userLocation else { return }
           let annotation = MKPointAnnotation()
           annotation.coordinate = location.coordinate
           map.addAnnotation(annotation)
    }

    @IBAction func carButton(_ sender: UIButton) {
        calculateRoute(for: .automobile)
    }
    
    @IBAction func bikeButton(_ sender: UIButton) {
        calculateRoute(for: .transit)

    }
    
    @IBAction func walkingButton(_ sender: UIButton) {
        calculateRoute(for: .walking)
    }
    
    func calculateRoute(for transportType: MKDirectionsTransportType) {
        guard let userLocation = userLocation,
              let destinationCoordinate = destinationCoordinate else {
            // Handle cases where either userLocation or destinationCoordinate is nil
            return
        }
        
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: userLocation.coordinate))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: destinationCoordinate))
        request.transportType = transportType
        
        let directions = MKDirections(request: request)
        directions.calculate { [weak self] response, error in
            guard let route = response?.routes.first, let strongSelf = self else {
                // Handle cases where route calculation fails or response is nil
                return
            }
            
            // Remove existing overlays (polylines)
            strongSelf.map.removeOverlays(strongSelf.map.overlays)
            
            // Add the new route (polyline) to the map
            strongSelf.map.addOverlay(route.polyline)
            
            // Optionally, fit the map to the route's bounding map rect
            strongSelf.map.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
        }
    }
    
    @IBAction func plusButton(_ sender: Any) {
        let alert = UIAlertController(title: "Where would you like to go?",message: "Enter your destination", preferredStyle: .alert)
           alert.addTextField { textField in
               textField.placeholder = "Write a place"
           }
           
           let confirmAction = UIAlertAction(title: "OK", style: .default) { [weak self] _ in
               guard let cityName = alert.textFields?.first?.text, !cityName.isEmpty else {
                   // Show an alert indicating that the city name is empty or invalid
                   self?.showAlert(message: "Please enter the name of the city")
                   return
               }
               
               // Use Geocoding to get coordinates for the entered city name
               self?.getCoordinates(for: cityName)
           }
           
           let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
           
           alert.addAction(confirmAction)
           alert.addAction(cancelAction)
           present(alert, animated: true)
    }
    
    func getCoordinates(for cityName: String) {
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(cityName) { [weak self] placemarks, error in
            if let error = error {
                print("Geocoding error: \(error.localizedDescription)")
                // Show an alert indicating geocoding error
                self?.showAlert(message: "Geocoding error: \(error.localizedDescription)")
                return
            }
            
            guard let placemark = placemarks?.first, let location = placemark.location else {
                // Show an alert indicating no location found for the entered city
                self?.showAlert(message: "No location found for the entered city")
                return
            }
            
            // Update destinationCoordinate with the new coordinates
            self?.destinationCoordinate = location.coordinate
            self?.addPinForDestination()
            self?.showRoute()

        }
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
    
    func addPinForDestination() {
//           map.removeAnnotations(map.annotations) // Clear existing annotations
           guard let coordinate = destinationCoordinate else { return }
           let annotation = MKPointAnnotation()
           annotation.coordinate = coordinate
           annotation.title = "Destination"
           map.addAnnotation(annotation)
           map.showAnnotations([annotation], animated: true)
    }

    func showRoute() {
        guard let userLocation = userLocation,
                let destinationCoordinate = destinationCoordinate else {
              // Handle cases where either userLocation or destinationCoordinate is nil
              return
          }
          
          let request = MKDirections.Request()
          request.source = MKMapItem(placemark: MKPlacemark(coordinate: userLocation.coordinate))
          request.destination = MKMapItem(placemark: MKPlacemark(coordinate: destinationCoordinate))
          request.transportType = .walking // Set transportType to walking
          
          let directions = MKDirections(request: request)
          directions.calculate { [weak self] response, error in
              guard let route = response?.routes.first, let strongSelf = self else {
                  // Handle cases where route calculation fails or response is nil
                  return
              }
              
              // Remove existing overlays (polylines)
              strongSelf.map.removeOverlays(strongSelf.map.overlays)
              
              // Add the new route (polyline) to the map
              strongSelf.map.addOverlay(route.polyline)
              
              // Optionally, fit the map to the route's bounding map rect
              strongSelf.map.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
              
              // Add annotations for start and end points
              let startAnnotation = MKPointAnnotation()
              startAnnotation.coordinate = userLocation.coordinate
              startAnnotation.title = "Start"
              strongSelf.map.addAnnotation(startAnnotation)
              
              let endAnnotation = MKPointAnnotation()
              endAnnotation.coordinate = destinationCoordinate
              endAnnotation.title = "End"
              strongSelf.map.addAnnotation(endAnnotation)
              
          }
    }
    
//    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
//        guard !(annotation is MKUserLocation) else { return nil }
//
//        let annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "CustomAnnotation")
//        annotationView.markerTintColor = UIColor.blue
//
//        return annotationView
//    }

    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polyline = overlay as? MKPolyline {
               let renderer = MKPolylineRenderer(polyline: polyline)
               renderer.strokeColor = .yellow
               renderer.lineWidth = 3
               return renderer
           }
           return MKOverlayRenderer()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
