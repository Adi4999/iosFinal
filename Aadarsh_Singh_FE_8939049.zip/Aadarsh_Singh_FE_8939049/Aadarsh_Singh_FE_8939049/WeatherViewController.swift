

import UIKit
import UIKit
import Foundation
import CoreLocation
import CoreData
class WeatherViewController: UIViewController, CLLocationManagerDelegate  {
    
    var city: String?
    let locationManager = CLLocationManager()
    var currentLocation : CLLocation?

    var lat : Double?
    var lon : Double?
    
    //outlets
    @IBOutlet weak var cityInfo: UITextView!
    @IBOutlet weak var cityNameLabel: UILabel!
    @IBOutlet weak var weatherImage: UIImageView!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var humidityLable: UILabel!
    @IBOutlet weak var windLable: UILabel!
    @IBOutlet weak var weatherType: UILabel!
    
    @IBAction func plusButton(_ sender: Any) {
        showCityAlert()
    }
    
    func showCityAlert(){
        let alert = UIAlertController(title: "Where would you like to go?",message: "Enter your new destination", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK",style: .default, handler: {action in if let cityName = alert.textFields?.first?.text, !cityName.isEmpty {
            self.fetchWeatherData(for: cityName)
            }
            else{
                self.showAlert(message: "Please enter the name of the city")
            }
            }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: {action in print("tapped Directions")}))
      
        alert.addTextField{field in field.placeholder = "Write a place"}
        
        present(alert, animated: true)
    }
    
    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
            super.viewDidLoad()
        
            if let city = city {
                fetchWeatherData(for: city)
            }
            else{
               let currentCity = "Waterloo"
                fetchWeatherData(for: currentCity)
            }
        }
    
    private func fetchWeatherData(for city: String) {
        print("name")
        //Api String
        let apiKey = "0b52d40aef4d4006fd01fccfff53725b"
        let baseUrl = "https://api.openweathermap.org/data/2.5/weather"
        let urlString = "\(baseUrl)?q=\(city)&appid=\(apiKey)&units=metric"
        
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] (data, response, error) in
            if let error = error {
                print("Error fetching weather data: \(error)")
                return
            }
            
            if let data = data {
                do {
                    let decoder = JSONDecoder()
                    let weatherDataInfo = try decoder.decode(weatherData.self, from: data)
                    
                    // Updates UI elements
                    DispatchQueue.main.async {
                        self?.updateUI(with: weatherDataInfo)
                        self?.updateCityInfo(cityName: weatherDataInfo.name, longitude: weatherDataInfo.coord.lon, latitude: weatherDataInfo.coord.lat)
                    }
                } catch {
                    print("Error decoding weather data: \(error)")
                }
            }
        }
        
        task.resume()
    }
    //function for weatherdata
    private func updateUI(with weatherData: weatherData) {
        cityNameLabel.text = weatherData.name
        temperatureLabel.text = "\(weatherData.main.temp)°C"
        humidityLable.text = "Humidity: \(weatherData.main.humidity)%"
        windLable.text = "Wind: \(weatherData.wind.speed) km/h"
        
      
        
    
        
        // Load weather icon
        if let icon = weatherData.weather.first?.icon {
            let iconUrl = "https://openweathermap.org/img/w/\(icon).png"
            if let url = URL(string: iconUrl) {
                URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
                    if let error = error {
                        print("Error loading weather icon: \(error)")
                        return
                    }
                    if let data = data, let image = UIImage(data: data) {
                        DispatchQueue.main.async {
                            self?.weatherImage.image = image
                        }
                    }
                }.resume()
            }
        }
        weatherType.text = weatherData.weather.first?.main
        
    }
    //function to print data of city( Name,Longitude & Latitude)
    func updateCityInfo(cityName: String, longitude: Double, latitude: Double) {

        cityInfo.text = """
        City: \(cityName)
        Longitude: \(longitude)
        Latitude: \(latitude)
        """
    }
}
  
// MARK: - Welcome
struct weatherData: Codable {
    let coord: Coord
    let weather: [Weather]
    let base: String
    let main: Main
    let visibility: Int
    let wind: Wind
    let rain: Rain?
    let clouds: Clouds
    let dt: Int
    let sys: Sys
    let timezone, id: Int
    let name: String
    let cod: Int
}
// MARK: - Clouds
struct Clouds: Codable {
    let all: Int
}

// MARK: - Coord
struct Coord: Codable {
    let lon, lat: Double
}

// MARK: - Main
struct Main: Codable {
    let temp, feelsLike, tempMin, tempMax: Double
    let pressure, humidity: Int

    enum CodingKeys: String, CodingKey {
        case temp
        case feelsLike = "feels_like"
        case tempMin = "temp_min"
        case tempMax = "temp_max"
        case pressure, humidity
    }
}

// MARK: - Rain
struct Rain: Codable {
    let the1H: Double

    enum CodingKeys: String, CodingKey {
        case the1H = "1h"
    }
}

// MARK: - Sys
struct Sys: Codable {
    let type, id: Int
    let country: String
    let sunrise, sunset: Int
}

// MARK: - Weather
struct Weather: Codable {
    let id: Int
    let main, description, icon: String
}

// MARK: - Wind
struct Wind: Codable {
    let speed: Double
    let deg: Int
    let gust: Double?
}
